-keepattributes *Annotation*
-keepclassmembers class * {
    @androidx.room.* *;
}
-keep class np.made.ammu.data.remote.model.** { *; }
