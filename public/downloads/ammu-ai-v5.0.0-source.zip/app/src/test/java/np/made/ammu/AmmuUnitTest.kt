package np.made.ammu

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AmmuUnitTest {
    @Test
    fun packageIdentity_isCorrect() {
        val packageName = "np.made.ammu"
        val versionName = "5.0.0"
        assertEquals("np.made.ammu", packageName)
        assertEquals("5.0.0", versionName)
    }

    @Test
    fun reminderRecurrence_calculation() {
        val oneDay = 24 * 60 * 60 * 1000L
        val nextTrigger = System.currentTimeMillis() + oneDay
        assertTrue(nextTrigger > System.currentTimeMillis())
    }
}
