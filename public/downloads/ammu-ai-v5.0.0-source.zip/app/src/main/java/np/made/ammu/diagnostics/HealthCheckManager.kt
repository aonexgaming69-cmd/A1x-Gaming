package np.made.ammu.diagnostics

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build

enum class HealthStatus {
    PASS, FAIL, BLOCKED, NOT_CONFIGURED
}

data class DiagnosticResult(
    val name: String,
    val status: HealthStatus,
    val message: String,
    val latencyMs: Long? = null
)

class HealthCheckManager(private val context: Context) {
    fun checkInternet(): DiagnosticResult {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return DiagnosticResult("Internet Connection", HealthStatus.FAIL, "No active network")
        val caps = cm.getNetworkCapabilities(network) ?: return DiagnosticResult("Internet Connection", HealthStatus.FAIL, "No network capabilities")
        val hasInternet = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        return if (hasInternet) {
            DiagnosticResult("Internet Connection", HealthStatus.PASS, "Active network online")
        } else {
            DiagnosticResult("Internet Connection", HealthStatus.FAIL, "No internet access")
        }
    }

    fun checkExactAlarm(): DiagnosticResult {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val am = context.getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager
            if (am.canScheduleExactAlarms()) {
                DiagnosticResult("Exact Alarm Capability", HealthStatus.PASS, "Exact alarms permitted")
            } else {
                DiagnosticResult("Exact Alarm Capability", HealthStatus.BLOCKED, "Permission required in Android 12+")
            }
        } else {
            DiagnosticResult("Exact Alarm Capability", HealthStatus.PASS, "Supported by platform version")
        }
    }
}
