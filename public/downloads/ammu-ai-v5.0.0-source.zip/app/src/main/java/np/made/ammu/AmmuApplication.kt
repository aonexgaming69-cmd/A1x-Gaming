package np.made.ammu

import android.app.Application
import android.util.Log

class AmmuApplication : Application() {
    companion object {
        const val TAG = "AMMU_AI"
        lateinit var instance: AmmuApplication
            private set
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        Log.i(TAG, "AMMU AI v5.0.0 initializing for package np.made.ammu")
    }
}
