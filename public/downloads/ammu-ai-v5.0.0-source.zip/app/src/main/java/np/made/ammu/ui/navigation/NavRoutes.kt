package np.made.ammu.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import np.made.ammu.ui.screens.*

sealed class Screen(val route: String, val title: String) {
    object Home : Screen("home", "Home")
    object Chat : Screen("chat", "AI Chat")
    object Voice : Screen("voice", "Nepali Voice")
    object Reminders : Screen("reminders", "Reminders")
    object Calls : Screen("calls", "Call Assistant")
    object Health : Screen("health", "Health Center")
    object Server : Screen("server", "Server Manager")
    object Memory : Screen("memory", "Memory Bank")
    object Settings : Screen("settings", "Settings")
    object About : Screen("about", "About AMMU")
}

@Composable
fun AmmuNavHost() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = Screen.Home.route) {
        composable(Screen.Home.route) { HomeScreen(navController) }
        composable(Screen.Chat.route) { ChatScreen(navController) }
        composable(Screen.Voice.route) { VoiceScreen(navController) }
        composable(Screen.Reminders.route) { ReminderScreen(navController) }
        composable(Screen.Calls.route) { CallAssistantScreen(navController) }
        composable(Screen.Health.route) { HealthCenterScreen(navController) }
        composable(Screen.Server.route) { ServerManagerScreen(navController) }
        composable(Screen.Memory.route) { MemoryScreen(navController) }
        composable(Screen.Settings.route) { SettingsScreen(navController) }
        composable(Screen.About.route) { AboutScreen(navController) }
    }
}
