package np.made.ammu.reminders

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import np.made.ammu.data.local.AppDatabase

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED || intent.action == "android.intent.action.QUICKBOOT_POWERON") {
            Log.d("AMMU_BOOT", "Device reboot completed. Restoring active AMMU AI alarms...")
            val alarmManager = ReminderAlarmManager(context)
            val db = AppDatabase.getInstance(context)
            CoroutineScope(Dispatchers.IO).launch {
                val now = System.currentTimeMillis()
                val pending = db.reminderDao().getAllReminders().filter { !it.isCompleted && it.dueTimestamp > now }
                for (reminder in pending) {
                    alarmManager.scheduleReminder(reminder.id, reminder.title, reminder.dueTimestamp)
                }
                Log.d("AMMU_BOOT", "Successfully restored ${pending.size} scheduled reminders.")
            }
        }
    }
}
