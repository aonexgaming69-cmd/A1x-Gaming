package np.made.ammu.data.remote

import retrofit2.Response
import retrofit2.http.*

data class ChatRequest(
    val messages: List<ChatMessageDto>,
    val language: String = "ne", // ne, hi, en
    val contextMemory: List<String> = emptyList()
)

data class ChatMessageDto(
    val role: String,
    val content: String
)

data class ChatResponse(
    val reply: String,
    val language: String,
    val memoryExtracted: List<String> = emptyList()
)

data class HealthResponse(
    val status: String,
    val latencyMs: Long,
    val checks: Map<String, String>
)

interface AmmuApiService {
    @POST("api/v1/chat")
    suspend fun sendChat(@Body req: ChatRequest): Response<ChatResponse>

    @GET("api/v1/health")
    suspend fun checkHealth(): Response<HealthResponse>
}
