package np.made.ammu.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val CrimsonPrimary = Color(0xFFC41230)
val CrimsonDark = Color(0xFF8B0018)
val HimalayanBlue = Color(0xFF1E3A8A)
val GoldAccent = Color(0xFFF59E0B)
val BackgroundDark = Color(0xFF0F172A)
val SurfaceDark = Color(0xFF1E293B)
val TextLight = Color(0xFFF8FAFC)

private val DarkColorScheme = darkColorScheme(
    primary = CrimsonPrimary,
    secondary = HimalayanBlue,
    tertiary = GoldAccent,
    background = BackgroundDark,
    surface = SurfaceDark,
    onPrimary = Color.White,
    onBackground = TextLight,
    onSurface = TextLight
)

@Composable
fun AmmuTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}
