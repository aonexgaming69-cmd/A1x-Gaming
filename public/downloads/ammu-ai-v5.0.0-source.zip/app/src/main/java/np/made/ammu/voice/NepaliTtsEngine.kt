package np.made.ammu.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.util.Log
import java.util.Locale

class NepaliTtsEngine(private val context: Context, private val onInitState: (Boolean) -> Unit) : TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = TextToSpeech(context, this)
    private var isReady = false

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isReady = true
            val neLocale = Locale("ne", "NP")
            val result = tts?.isLanguageAvailable(neLocale)
            Log.d("NepaliTTS", "Nepali locale support: $result")
            onInitState(true)
        } else {
            isReady = false
            onInitState(false)
        }
    }

    fun speak(text: String, languageCode: String = "ne") {
        if (!isReady || tts == null) return
        val targetLocale = when (languageCode) {
            "ne" -> Locale("ne", "NP")
            "hi" -> Locale("hi", "IN")
            else -> Locale.US
        }
        tts?.language = targetLocale
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ammu_speech_${System.currentTimeMillis()}")
    }

    fun stop() {
        tts?.stop()
    }

    fun shutdown() {
        tts?.shutdown()
        tts = null
    }
}
