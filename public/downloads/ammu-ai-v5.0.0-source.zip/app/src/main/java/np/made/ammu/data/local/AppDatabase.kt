package np.made.ammu.data.local

import android.content.Context
import androidx.room.*

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val text: String,
    val sender: String, // "user" or "ammu"
    val language: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Dao
interface ChatMessageDao {
    @Query("SELECT * FROM chat_messages ORDER BY timestamp ASC")
    suspend fun getAllMessages(): List<ChatMessageEntity>

    @Insert
    suspend fun insertMessage(msg: ChatMessageEntity): Long

    @Query("DELETE FROM chat_messages")
    suspend fun clearHistory()
}

@Entity(tableName = "reminders")
data class ReminderEntity(
    @PrimaryKey val id: String,
    val title: String,
    val note: String,
    val dueTimestamp: Long,
    val recurrence: String, // NONE, DAILY, WEEKLY, WEEKDAYS, MONTHLY
    val priority: String, // NORMAL, MEDIUM, HIGH
    val isCompleted: Boolean = false
)

@Dao
interface ReminderDao {
    @Query("SELECT * FROM reminders ORDER BY dueTimestamp ASC")
    suspend fun getAllReminders(): List<ReminderEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(reminder: ReminderEntity)

    @Delete
    suspend fun delete(reminder: ReminderEntity)

    @Query("UPDATE reminders SET isCompleted = :completed WHERE id = :id")
    suspend fun setCompleted(id: String, completed: Boolean)
}

@Entity(tableName = "user_memory")
data class MemoryEntity(
    @PrimaryKey val id: String,
    val category: String, // PREFERENCE, FACT, PERSON, TASK
    val content: String,
    val confidence: Float = 1.0f,
    val updatedAt: Long = System.currentTimeMillis()
)

@Dao
interface MemoryDao {
    @Query("SELECT * FROM user_memory ORDER BY updatedAt DESC")
    suspend fun getAllMemory(): List<MemoryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: MemoryEntity)

    @Query("DELETE FROM user_memory WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("DELETE FROM user_memory")
    suspend fun clearAll()
}

@Database(entities = [ChatMessageEntity::class, ReminderEntity::class, MemoryEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun chatDao(): ChatMessageDao
    abstract fun reminderDao(): ReminderDao
    abstract fun memoryDao(): MemoryDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        fun getInstance(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "ammu_ai.db"
                ).build().also { INSTANCE = it }
            }
    }
}
