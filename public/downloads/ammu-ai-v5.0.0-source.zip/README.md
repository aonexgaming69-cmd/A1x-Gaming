# AMMU AI - Professional Android AI Assistant (v5.0.0)

**Package Name:** `np.made.ammu`
**Platform:** Android (Min SDK 26, Target SDK 35) & Web Companion / Server
**Supported Languages:** Nepali (नेपाली), Hindi (हिन्दी), English

## Features
- **Intelligent Conversational Engine:** Powered by Google Gemini with context retention and streaming.
- **Nepali Voice Assistant:** Native Nepali Speech-to-Text (`ne-NP`) and Nepali Text-to-Speech synthesis.
- **Smart Phone Call Assistant:** Secure contact picker, confirmation guard, safe dialer (`Intent.ACTION_DIAL`).
- **Smart Reminders:** Exact alarm scheduling (`SCHEDULE_EXACT_ALARM`), Boot receiver restoration, recurrence.
- **Memory System:** Long-term memory facts, conversation history, privacy controls.
- **14-Point Health Center:** Internet, DNS, HTTPS, Gemini API, Audio/Notification permissions, TTS/STT diagnostic engine with real PASS/FAIL statuses.
- **Smart Server Manager:** Dynamic backend endpoint validation, latency tester, SSL inspection.

## Directory Structure
```
├── android/
│   ├── app/
│   │   ├── src/main/java/np/made/ammu/
│   │   │   ├── AmmuApplication.kt
│   │   │   ├── MainActivity.kt
│   │   │   ├── data/local/ (Room Database, DAOs)
│   │   │   ├── data/remote/ (Retrofit API Service)
│   │   │   ├── voice/ (Nepali SpeechRecognizer, Nepali TTS)
│   │   │   ├── reminders/ (Alarms, BootReceiver)
│   │   │   ├── diagnostics/ (HealthCheckManager)
│   │   │   └── ui/screens/ (Jetpack Compose Screens)
│   │   └── src/main/res/ (Nepali, Hindi, English string resources)
│   ├── build.gradle.kts
│   └── settings.gradle.kts
├── server.ts (Production Express Backend + Gemini API Integration)
├── src/ (Interactive Web App & Live Android Phone Simulator)
└── public/downloads/ (ammu-ai-v5.0.0.apk)
```
